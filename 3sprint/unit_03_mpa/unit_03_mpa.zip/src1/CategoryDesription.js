import { useParams } from "react-router-dom"
function CategoryDesription() {
    let { categoryName } = useParams();

    return (
        <>
            <a href="/cat">Назад</a>
            <h1>Category:{categoryName}</h1>
        </>
    )
}


export default CategoryDesription