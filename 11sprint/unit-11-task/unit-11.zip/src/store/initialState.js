const initialState = {
    users: [
        {
            passport: 'aze',
            name: 'Murvat',
            age: '1'

        }

    ]
}
export default initialState